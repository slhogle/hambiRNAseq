#!/usr/bin/bash

multiqc -n hambiRNAseq --no-data-dir -m fastqc hambiRNAseq
tar -czf hambiRNAseq.tar.gz hambiRNAseq

# printf '%s\n' * > files.txt
# split -l 38 files.txt
# ls xa* > dirs.txt

# cat dirs.txt | while read id; do mkdir iina_16S_postprocess_${id}; done
# cat dirs.txt | while read id; do cat ${id} | parallel mv {} iina_16S_postprocess_${id}; done

# rm -rf xa*

# cat dirs.txt | while read id; do multiqc -n iina_16S_postprocess_${id} --no-data-dir -m fastqc iina_16S_postprocess_${id}; done

# cat dirs.txt | while read id; do tar -czvf iina_16S_postprocess_${id}.tar.gz fastqc iina_16S_postprocess_${id}; done

# cat dirs.txt | while read id; do rm -rf iina_16S_postprocess_${id}; done


