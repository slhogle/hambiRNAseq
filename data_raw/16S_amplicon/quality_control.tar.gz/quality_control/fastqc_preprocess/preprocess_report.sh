#!/usr/bin/bash

multiqc -n hambiRNAseq --no-data-dir -m fastqc hambiRNAseq
tar -czf hambiRNAseq.tar.gz hambiRNAseq

# printf '%s\n' * > files.txt
# split -l 88 files.txt
# ls xa* > dirs.txt

# cat dirs.txt | while read id; do mkdir liisa-fullcommunity_16S_preprocess_${id}; done
# cat dirs.txt | while read id; do cat ${id} | parallel mv {} liisa-fullcommunity_16S_preprocess_${id}; done

# rm -rf xa*

# cat dirs.txt | while read id; do multiqc -n liisa-fullcommunity_16S_preprocess_${id} --no-data-dir -m fastqc liisa-fullcommunity_16S_preprocess_${id}; done

# cat dirs.txt | while read id; do tar -czvf liisa-fullcommunity_16S_preprocess_${id}.tar.gz fastqc liisa-fullcommunity_16S_preprocess_${id}; done

# cat dirs.txt | while read id; do rm -rf liisa-fullcommunity_16S_preprocess_${id}; done
