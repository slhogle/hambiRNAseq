#!/usr/bin/env bash

module load biopythontools

rename 's/.html/.fastp.html/' *
rename 's/.json/.fastp.json/' *

printf '%s\n' * > files.txt
split -l 20 files.txt
ls xa* > dirs.txt

cat dirs.txt | while read id; do mkdir mapqc_${id}; done
cat dirs.txt | while read id; do cat ${id} | parallel mv {} mapqc_${id}; done

rm -rf xa*

cat dirs.txt | while read id; do multiqc -n mapqc_${id} --no-data-dir mapqc_${id}; done

cat dirs.txt | while read id; do tar -czvf mapqc_${id}.tar.gz mapqc_${id}; done

cat dirs.txt | while read id; do rm -rf mapqc_${id}; done
